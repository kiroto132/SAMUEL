#ecenrio 1 el heroe esta solo y escoge la mejor opcion para ganar\n
# ten en cuenta que puede haber civiles y estan en riesgo 
vulnerable = 100
villano = input("el villano es: fuerte o debil:\n")
civiles = input("¿hay civiles cerca?:\n")

if civiles == "si":
    repuesta = input("¿hay civiles en peligro?:\n")
    if repuesta == "si":
        print("Veo que hay personas en peligro, debes tomar una decision")
        repuesta = input("Consideras que tienes lo necesario para salvar a las personas?:\n")
        if repuesta == 'si':
            print("entonces vamos a actuar.")
            repuesta = input("Vas a atacar al villano? ")
            if repuesta == 'si':
                if villano == 'fuerte':
                    print("Te sientes confiado! Ten cuidado con la seguridad del civil")
                    repuesta = input ("Acertaste el golpe? ")
                    if repuesta == 'si':
                        print("Gran golpe vaquero, lograste poner a salvo al civil!")
                    elif repuesta == 'no':
                        print("Fallar te pudo haber costado caro, pero lograste salvar al civil.")
                        vulnerable -= 50
                elif villano == 'debil':
                    print("Hora de atacar, acertaste un gran ataque y salvaste al civil")
            elif repuesta == 'no':
                print("movimiento veloz y salvamos al civil sin recibir mucho daño")
                vulnerable -= 15
    else:
        print("Situacion compleja, lo primordial es salvar al civil")
        print("Se ha llamado a la policia, vigila al villano de cerca mientras llegan")
elif civiles == "no":
    print("evalua la situacion")
if villano == "fuerte":
        repuesta = input("¿Quieres pedir refuerzos?:\n")
        if repuesta == "si":
            print("Estas esperando refuerzos (15 a 20 minutos)")
            repuesta = input("los refuerzos llegaron a tiempo:\n")
            if repuesta == "si":
                print("puedes entrar a la batalla")
            elif repuesta == "no":
                    print("consigue tiempo hasta que lleguen los refuerzos")
        if repuesta == "no":
            repuesta = input("¿te sintes confiado para tener una batalla?:\n")
            if repuesta == "si":
                print("Estas en la batalla")
                vulnerable -= 50
            elif repuesta == "no":
                print("evalua la situacion")
elif villano =="debil":
    print("como eres tan fuerte y valiente ve a la batalla")
if vulnerable <= 50:
    print("estas muy vulnerable que quieres hacer?")
    repuesta = input(" quieres recuperarte o seguir luchando:\n")
    if repuesta == "recuperarte":
        print("La ciudad esta en riesgo, mejorate pronto para que no nos muramos")
    elif repuesta == "luchar":
        print("Estas en peligro!! te estas muriendo")
